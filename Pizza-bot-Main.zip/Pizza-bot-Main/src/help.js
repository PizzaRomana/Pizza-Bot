const help = (prefix, pushname, botname, oname) => {
	return `
  「 *Meu Bot* 」
࿇ ══━━━━✥◈✥━━━━══ ࿇
  SALVE✌️🏻
  
  ◪ *INFORMAÇÕES*
    ❏ Prefix: 「  ${prefix}  」
    ❏ Criador: PizzaRomana
    ❏ Numero do meu criador:(11)94643-5579
 ࿇ ══━━━━✥◈✥━━━━══ ࿇
    Outros Menus
    ❏${prefix}nsfwmenu
    ❏${prefix}menuadmin
  
    
  ◪ *LEVEL*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}leveling
    └─ ❏ ${prefix}level
  ◪ *CRIAR*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}sticker
    ├─ ❏ ${prefix}toimg
    ├─ ❏ ${prefix}bpink
    ├─ ❏ ${prefix}marvellogo
    ├─ ❏ ${prefix}snowwrite
    ├─ ❏ ${prefix}3dtext
    ├─ ❏ ${prefix}ninjalogo
    ├─ ❏ ${prefix}water
    ├─ ❏ ${prefix}firetext
    ├─ ❏ ${prefix}neonlogo
    ├─ ❏ ${prefix}lionlogo
    ├─ ❏ ${prefix}jokerlogo
    └─ ❏ ${prefix}quotemaker
  ◪ *PESQUISA*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}wikien (Apenas pesquisas em Ingles)
  ◪ *DOWNLOADER*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}images 
    ├─ ❏ ${prefix}ytmp3
    ├─ ❏ ${prefix}ytmp4
    ├─ ❏ ${prefix}joox
    ├─ ❏ ${prefix}joox2
    ├─ ❏ ${prefix}trendtwit
    └─ ❏ ${prefix}ytsearch
  ◪ *MEME*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}meme
  ◪ *Roleta Harém*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}neonime
    ├─ ❏ ${prefix}pokemon
    ├─ ❏ ${prefix}loli
    ├─ ❏ ${prefix}waifu
    ├─ ❏ ${prefix}walpaper
    ├─ ❏ ${prefix}neko
    └─ ❏ ${prefix}nekonime
  ◪ *OUTROS*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}send
    ├─ ❏ ${prefix}wame
    ├─ ❏ ${prefix}virtex
    ├─ ❏ ${prefix}exe
    ├─ ❏ ${prefix}qrcode
    ├─ ❏ ${prefix}quotes
    └─ ❏ ${prefix}fml
  `
}

exports.help = help
