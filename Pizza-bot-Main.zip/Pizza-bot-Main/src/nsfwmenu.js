const nsfwmenu = (prefix, pushname) => {
    return `Bom, esse é o meno NSFW, se você não sabe oq é, é recomendado não usar
    ◪ *NSFW*
  │
  ├─ ❏ ${prefix}nsfwbobs
  ├─ ❏ ${prefix}randomhentaio
  ├─ ❏ ${prefix}nsfwass (OFF)
  ├─ ❏ ${prefix}nsfwsidebobs
  ├─ ❏ ${prefix}nsfwahegao
  ├─ ❏ ${prefix}nsfwthighs
  ├─ ❏ ${prefix}nsfwarmpits
  └─ ❏ ${prefix}nsfwfeets

  _obs para usar esses comandos ative o menu NSFW_\n _Digite_\n ${prefix}*nsfw 1*`



}

exports.nsfwmenu = nsfwmenu