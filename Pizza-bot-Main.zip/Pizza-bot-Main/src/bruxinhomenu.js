const bruxinhomenu = (prefix, pushname) => {
    return `◪ *Comandos do bruxinho*
    │
    ├─ ❏ ${prefix}setprefix
    ├─ ❏ ${prefix}block
    ├─ ❏ ${prefix}bc
    ├─ ❏ ${prefix}bcgc
    └─ ❏ ${prefix}clearall`

}

exports.bruxinhomenu = bruxinho
